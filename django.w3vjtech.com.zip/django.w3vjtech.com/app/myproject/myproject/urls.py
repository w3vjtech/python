from django.urls import path, include
from myapp import views


urlpatterns = [
    path('myapp/', include('myapp.urls')),
    path('', views.index, name='index'),
    # Add your other URL patterns here
]
